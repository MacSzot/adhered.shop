import { NextResponse } from "next/server";

export async function POST(request: Request){
  const data = await request.json().catch(()=>({}));
  console.log("LOG EVENT:", data);
  return NextResponse.json({ ok: true });
}