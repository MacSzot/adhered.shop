"use client";
import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";

const DAY = "day01"; // na start demo; potem z tokena

export default function Day() {
  const params = useSearchParams();
  const initialTab = params.get("tab") || "prompter";
  const [tab, setTab] = useState<"prompter"|"rysownik">(initialTab === "rysownik" ? "rysownik" : "prompter");
  const [text, setText] = useState<string>("");
  const [done, setDone] = useState(false);

  // Kamera
  const videoRef = useRef<HTMLVideoElement>(null);
  const [mediaErr, setMediaErr] = useState<string>("");

  async function startCam() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (e:any) {
      setMediaErr("Zezwól przeglądarce na kamerę i mikrofon.");
    }
  }

  // Wczytaj tekst
  useEffect(() => {
    fetch(`/days/${DAY}/prompter.txt`).then(r => r.text()).then(setText).catch(()=>setText("Brak pliku promptera."));
  }, []);

  // Proste auto-scrollowanie
  const scrollRef = useRef<HTMLDivElement>(null);
  const [scrolling, setScrolling] = useState(false);
  useEffect(() => {
    if (!scrolling || !scrollRef.current) return;
    let id:number;
    const step = () => {
      const el = scrollRef.current!;
      el.scrollTop += 1; // prędkość
      const hitEnd = el.scrollTop + el.clientHeight >= el.scrollHeight - 2;
      if (hitEnd) { setDone(true); setScrolling(false); return; }
      id = window.requestAnimationFrame(step);
    };
    id = window.requestAnimationFrame(step);
    return () => window.cancelAnimationFrame(id);
  }, [scrolling]);

  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <div className="flex items-center justify-between">
        <div className="text-sm text-neutral-400">Użytkownik: demo • Dzień 1</div>
        <span className={`chip ${done ? "bg-green-900 text-green-100" : "bg-neutral-800 text-neutral-300"}`}>
          {done ? "zrobione" : "w toku"}
        </span>
      </div>

      {/* Tabs */}
      <div className="mt-4 flex gap-3">
        <button onClick={()=>setTab("prompter")}
          className={`rounded-full px-4 py-2 ${tab==="prompter"?"bg-neutral-800 text-white":"bg-neutral-900/40 text-neutral-300"}`}>
          1) Prompter
        </button>
        <button onClick={()=>setTab("rysownik")}
          className={`rounded-full px-4 py-2 ${tab==="rysownik"?"bg-neutral-800 text-white":"bg-neutral-900/40 text-neutral-300"}`}>
          2) Rysownik
        </button>
      </div>

      {/* Prompter */}
      {tab==="prompter" && (
        <section className="mt-6 rounded-2xl border border-neutral-800 bg-black p-6">
          <h2 className="text-2xl font-bold mb-2">Prompter — Sesja</h2>
          <p className="mb-4 text-neutral-400">Kliknij Start, aby rozpocząć czytanie na głos. Tekst przewija się automatycznie.</p>

          <div className="mb-4 flex gap-3">
            <button onClick={startCam} className="rounded-lg bg-emerald-600 px-4 py-2 text-white">Start</button>
            <a href={`/day/solo`} className="rounded-lg border border-neutral-700 px-4 py-2">Otwórz w nowej karcie</a>
            <button disabled={!done} className={`rounded-lg px-4 py-2 ${done?"bg-emerald-900 text-emerald-100":"bg-neutral-800 text-neutral-500 cursor-not-allowed"}`}>
              Zrobione
            </button>
          </div>

          <div className="relative grid grid-cols-1 gap-4 md:grid-cols-2">
            {/* Kamera */}
            <div className="aspect-video rounded-xl bg-black">
              <video ref={videoRef} autoPlay playsInline className="h-full w-full rounded-xl object-cover" />
              {mediaErr && <p className="mt-2 text-sm text-red-400">{mediaErr}</p>}
            </div>

            {/* Tekst */}
            <div ref={scrollRef} className="h-80 overflow-y-auto rounded-xl bg-neutral-900 p-6 leading-relaxed text-neutral-100">
              <p className="whitespace-pre-wrap">{text}</p>
            </div>
          </div>

          {/* Sterowanie auto-scrollem */}
          <div className="mt-4 flex gap-3">
            <button onClick={()=>setScrolling(true)} className="rounded-lg border border-neutral-700 px-4 py-2">Auto-scroll start</button>
            <button onClick={()=>setScrolling(false)} className="rounded-lg border border-neutral-700 px-4 py-2">Stop</button>
          </div>
        </section>
      )}

      {/* Rysownik */}
      {tab==="rysownik" && (
        <section className="mt-6 rounded-2xl border border-neutral-800 bg-neutral-950 p-6">
          <h2 className="text-2xl font-bold mb-2">Rysownik</h2>
          <p className="mb-4 text-neutral-400">Podgląd poniżej. Kliknij „Pobierz”, aby zapisać.</p>
          <div className="mb-4 flex gap-3">
            <a download href={`/days/${DAY}/rysownik.jpg`} className="rounded-lg bg-white/10 px-4 py-2">Pobierz</a>
            <button className="rounded-lg border border-neutral-700 px-4 py-2">Zrobione</button>
          </div>
          <img src={`/days/${DAY}/rysownik.jpg`} alt="Rysownik" className="max-h-[70vh] w-auto rounded-xl border border-neutral-800" />
        </section>
      )}
    </main>
  );
}