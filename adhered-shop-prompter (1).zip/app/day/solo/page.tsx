export default function Solo(){return (<main className='p-10'>Tryb pełnoekranowy (placeholder).</main>)}
