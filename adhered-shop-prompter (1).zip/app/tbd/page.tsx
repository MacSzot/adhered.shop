export default function TBD(){return (<main className='p-10'>TBD — tu podłączymy następny moduł.</main>)}
