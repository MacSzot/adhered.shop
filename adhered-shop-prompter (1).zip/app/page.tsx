import Link from "next/link";

export default function Home() {
  return (
    <main className="mx-auto max-w-5xl px-6 py-16">
      <h1 className="text-5xl font-extrabold">adhered.</h1>
      <p className="mt-2 text-xl text-neutral-400">Led by dis order.</p>

      <div className="mt-12 grid gap-6 md:grid-cols-3">
        <Link href="/day" className="rounded-2xl border border-neutral-800 p-8 hover:shadow">
          Prompter
        </Link>
        <Link href="/day?tab=rysownik" className="rounded-2xl border border-neutral-800 p-8 hover:shadow">
          Rysownik
        </Link>
        <Link href="/tbd" className="rounded-2xl border border-neutral-800 p-8 hover:shadow">
          TBD
        </Link>
      </div>
    </main>
  );
}