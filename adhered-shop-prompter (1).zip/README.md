# adhered.shop — Prompter + Rysownik (App Router)

Minimalny szkielet Next.js + Tailwind do uruchomienia promptera (kamera + tekst) oraz rysownika (obraz dnia) na `/day`.

## Uruchomienie lokalne
```bash
npm i
npm run dev
# http://localhost:3000/day
```

## Wdrażanie na Vercel
1. Push do GitHub.
2. Import repo w Vercel → Framework: **Next.js**.
3. Domenę `adhered.shop` przypnij do projektu.

## Struktura
- `app/page.tsx` — strona główna (kafle Prompter / Rysownik / TBD)
- `app/day/page.tsx` — zakładki: **Prompter** (kamera + auto-scroll) i **Rysownik**
- `public/days/day01/` — pliki dnia (prompter.txt, rysownik.jpg)
- `app/api/log/route.ts` — stub logowania

## Uwaga
- W projekcie celowo **nie ma** słowa „Samotnik”; nazwy są neutralne.
- Tokeny, heartbeat i bind do urządzenia dodamy później (middleware).