# adhered.shop — Teleprompter

Teleprompter z kamerą, mikrofonem i tekstem na 6 minut.